package erebus.sincloud.Helpers;

public enum ButtonVisibility
{
    VISIBLE,
    INVISIBLE,
}
