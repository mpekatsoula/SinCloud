package erebus.sincloud.Helpers;

public enum RecordButtonStates
{
    START_RECORDING,
    STOP_RECORDING,
    PAUSE_RECORDING,
    UPLOAD_CANCEL,
}
